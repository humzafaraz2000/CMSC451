HOW TO RUN AND COMPILE

To compile there are 2 options:
1) Using makefile "make 451proj"
2) Using command line compiler "g++ 451proj.cpp -o 451proj"

To run there are 2 options:
1) Using makefile "make run"
2) Using command line compiler "./451proj projdata.txt